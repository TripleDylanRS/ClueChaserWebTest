# Keyboard Shortcuts

## Search

* ++f++ , ++s++ , ++slash++ : open search dialog
* ++arrow-down++ , ++arrow-up++ : select next / previous result
* ++arrow-right++ : complete search suggestion
* ++enter++ : follow selected result
* ++esc++ , ++tab++ : close search dialog