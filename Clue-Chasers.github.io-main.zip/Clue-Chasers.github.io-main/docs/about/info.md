# Information

Information about Clue Chasers and the website.

!!! note
    I hope to put the announcements from Discord here.

    For now this is mostly a placeholder
    
